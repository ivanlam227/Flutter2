package com.example.financial_accounting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
