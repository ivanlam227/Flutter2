class ScreenArguments {
  final String refreshToken;

  ScreenArguments(this.refreshToken);
}
